# VUKO Crypto Terminal

**Market Intelligence. Quantified.**

A Netlify-ready React / TypeScript crypto research terminal with an emerald-and-charcoal interface, 16 routes, explicit data provenance, deterministic trading calculations, secure provider adapters, and personal research tools.

## Readiness

This is a working release candidate, not a certified production trading platform. The source builds and the core financial/security tests pass. Production credentials, a target GitHub repository and a Netlify deployment have **not** been configured. External providers, billing limits and browser behavior must be verified in your deployment before public use. No order execution or custody exists.

Live mode is the default. **Explore demo** explicitly enables synthetic data. Demo prices are not current market prices, and demo backtests are not evidence of strategy performance.

## Run locally

Use Node.js 22 or newer.

```bash
npm ci
npm test
npm run build
npm run dev
```

Vite serves the frontend. Click **Explore demo** to use charts, heatmaps, risk calculations, the journal and backtests without API credentials. Do not expect Vite alone to serve Netlify Functions.

For full-stack local development:

```bash
cp .env.example .env
npx netlify-cli dev
```

Configure server credentials in `.env`; this file is git-ignored. Never put secrets in `VITE_*` variables. Production AI session cookies are Secure and should be exercised over HTTPS in a Netlify deploy preview.

## Deploy through GitHub → Netlify

1. Create or choose a GitHub repository and push **the contents of this folder**, including `netlify/`, `scripts/`, `package-lock.json`, and `netlify.toml`.
2. In Netlify choose **Add new project → Import an existing project → GitHub**, then select that repository.
3. Set the build command to `npm run build`, publish directory to `dist`, and Functions directory to `netlify/functions` (already specified in `netlify.toml`).
4. Add the environment variables below in Netlify. Give server secrets Functions/runtime scope. Give `DAILY_BRIEF_CRON` Build scope as well.
5. Deploy, then open `/settings`. Unlock protected research/vision access with your workspace password. Check provider status and actual endpoint responses.
6. Future commits to the connected production branch deploy automatically. GitHub CI runs tests, type-checking/build and a production dependency audit.

A frontend-only drag-and-drop of `dist` does **not** deploy these backend functions. Use the Git integration or Netlify CLI deploy with functions.

## Environment variables

| Variable | Purpose |
| --- | --- |
| `APP_ACCESS_PASSWORD` | Required to unlock AI/news requests. Use a strong unique password. Never share in source code. |
| `OPENAI_API_KEY` | Screenshot vision provider. |
| `OPENAI_VISION_MODEL` | Vision-capable model; default `gpt-4.1-mini`, replace based on your account access. |
| `FIRECRAWL_API_KEY` | Source-linked crypto and macro news search. |
| `COINGECKO_API_KEY` | Optional CoinGecko demo API key for market snapshots. |
| `TRADINGCURSOR_GATEWAY_URL` | Optional operator-controlled HTTPS gateway implementing the documented normalized contract. No undocumented vendor REST endpoint is assumed. |
| `TRADINGCURSOR_API_KEY` | Optional server-only gateway credential. |
| `ETHEREUM_RPC_URL` | Optional Ethereum mainnet JSON-RPC endpoint for ENS resolution. |
| `BRIEF_STORAGE` | `dynamic` (default), `blobs`, `supabase`, or `neon`. |
| `SUPABASE_URL` / `SUPABASE_SERVICE_ROLE_KEY` | Supabase persistent report adapter; server-only. |
| `DATABASE_URL` | Neon connection string; server-only. |
| `DAILY_BRIEF_CRON` | Five-field UTC cron. Default `30 2 * * *` = 08:00 India time. Rebuild after changing. |

Public market APIs can be restricted by region, rate limits, or provider policy. The UI displays failures rather than manufacturing data. AI, Firecrawl and hosting may incur charges; nothing here promises permanently free operations.

## Routes

| Route | Working surface |
| --- | --- |
| `/` | Summary, candlesticks, rule bias, multi-factor regime, movers, heatmap |
| `/markets` | Searchable, sortable market table and favorites |
| `/coin/:symbol` | Candlesticks, selectable indicators, evidence, funding and open interest |
| `/analysis` | Deterministic VUKO engine and optional TradingCursor comparison |
| `/chart-analyzer` | Image upload, protected vision request, uncertainty rules |
| `/heatmap` | Performance heatmap, categories, top 20/50/100, cap/volume weighting |
| `/onchain`, `/wallet/:address` | EVM lookup, ENS via configured RPC, tokens, NFTs, transactions, ABI/source and on-refresh change observations |
| `/news` | Daily report and source-linked news |
| `/quant`, `/backtest` | Four strategy presets, parameter editing, backtests, robustness sweeps |
| `/risk` | Position sizing, long/short linear exposure, heuristic risk assessment |
| `/journal` | Local completed-trade journal and realized PnL |
| `/predictions` | Timestamped hypotheses, manual or on-demand candle evaluation |
| `/watchlist` | Locally saved asset list |
| `/settings` | Provider configuration status, protected access, mode, export |

## Data and calculation boundaries

- CoinGecko supplies USD snapshots, 1H/24H/7D changes and market caps. Binance supplies USDT spot OHLCV and public streaming prices; USD and USDT are not identical instruments.
- A browser WebSocket provider reconnects exponentially with jitter. Old ticks are discarded after 30 seconds, while REST snapshots refresh every minute. Provider timestamps remain visible.
- The market regime combines BTC/ETH daily trend, BTC RSI and covered-asset 24H breadth. Liquidity, funding and on-chain factors are not fabricated when unavailable. The confidence percentage is **factor agreement**, not a calibrated forecast probability.
- The trade engine uses completed candles only, daily EMA200, a previous-20-candle 4H breakout, 2× ATR or farther structure stop, and 2R/3R reference targets. It defaults to WAIT on insufficient/stale history.
- `validateMarketAnalysis()` rejects contradictory comparisons and malformed position levels. Numeric calculations come from code. TradingCursor is a separate, schema-validated input and cannot override the rule engine. Unverified provider prose is not re-published as authoritative evidence.
- Screenshots are historical observations. The vision response is schema-validated, confidence-capped and penalized for unreadable information. Missing ticker, timeframe or price scale, blur, or confidence below 50 suppresses the plan. It never treats image prices as verified current prices.
- Position sizing excludes execution costs; the interface discloses this. Stops may gap. Liquidation is not computed without venue-specific maintenance-margin rules.
- Local journals and prediction ledgers are device-local, user-editable storage, not immutable audited records. Use **Export personal workspace** to back them up.

## Backtest assumptions

- Signals at the completed 4H close; entries at the next bar open with adverse slippage.
- Daily EMA uses only daily candles closed before the signal timestamp.
- Gap-through stops fill at the adverse opening price; otherwise stop reference plus adverse slippage.
- An exit decided at the prior close executes at the next open before later intrabar stop checks.
- Initial stop is max(ATR distance, channel structure distance). Trailing stops update for the following bar only.
- Both entry and exit fees are deducted. Size is capped at 1× equity. Final positions are closed at the sample end and charged costs.
- Sharpe and Sortino annualize marked-to-market 4H returns at 6×365.25 periods with a zero risk-free rate. CAGR is omitted below a one-year sample. Profit factor is N/A if no losses occurred.
- Perpetual funding, borrow availability/cost, liquidation, market impact and exchange outages are not modelled. Short results are theoretical. These omissions prevent treating the result as a validated perpetual strategy.
- Parameter sweeps are in-sample diagnostics, not walk-forward or out-of-sample proof.
- EMA Trend: a 20-EMA cross aligned with daily regime. Momentum: channel break plus >3% absolute 10-bar move. Mean Reversion: a 2-ATR displacement from EMA20 within daily regime. Shared ATR/channel exits apply to all presets.

## Daily reports and storage

`BriefRepository` supports Netlify Blobs, Supabase and Neon/Postgres. `scripts/schema.sql` creates the SQL table and enables RLS for Supabase. Do not create anonymous write policies. In dynamic mode there is no historical persistence; the report is calculated on request.

The schedule is compiled into a literal Netlify Function config during `npm run build`, because scheduling is deployment configuration, not a runtime environment-variable switch. Netlify runs schedules in UTC. The daily report uses deterministic synthesis and source-linked snippets; news importance and possible impact use disclosed headline heuristics, not inferred market causality; it does not generate unsupported scenario probabilities or LLM numeric facts.

## Security and operational limits

- Server-only credentials, fixed/allowlisted upstreams, request-size limits, image MIME/signature validation, Zod schemas, same-origin checks, signed HttpOnly/Secure sessions, and Netlify endpoint rate-limit configurations.
- The workspace password is a single-owner gate, **not multi-user authentication**. Replace it with proper identity/session management for a shared public product.
- Configure provider spending caps, Netlify limits and monitoring before public exposure. Verify that the selected Netlify plan supports the configured rate-limit features and required function duration.
- Do not store exchange secrets or private keys. No endpoint submits trades.
- CSP restricts scripts and connections; React escapes displayed news, contract code and model output.

## Explicit remaining scope

See [docs/FEATURE_STATUS.md](docs/FEATURE_STATUS.md). Main gaps: authenticated cloud journals, continuously scheduled wallet alerts, liquidation-history provider, 4H market-wide return feed, automatic technical refresh across every table row, calibrated AI forecasts, automated prediction scheduling, arbitrary no-code strategy rules and a monitored production deployment.

## Verification

- `npm test`: financial causality, sizing, gap fills, claim integrity, signed sessions, vendor schemas and prediction ambiguity.
- `npm run build`: TypeScript and production bundle.
- `npm audit --omit=dev`: dependency review.
- Browser-based visual/interaction QA and live provider end-to-end tests still need to run in the deployment environment.

## Primary implementation references

- [Netlify scheduling](https://docs.netlify.com/build/functions/scheduled-functions/)
- [Netlify function rate limiting](https://www.netlify.com/knowledge-base/how-to-build-and-deploy-an-mcp-server-on-netlify/)
- [Netlify Blobs](https://docs.netlify.com/build/data-and-storage/netlify-blobs/)
- [Firecrawl search](https://docs.firecrawl.dev/features/search)
- [TradingView Lightweight Charts](https://tradingview.github.io/lightweight-charts/)
- [Blockscout API](https://docs.blockscout.com/devs/apis)

The attached Crypto Trading Strategy Playbook informed the trend/momentum and risk-control structure. Research claims in that PDF are not a guarantee of out-of-sample results.
