import {generateBrief,repository} from '../shared/brief';
export default async()=>{const brief=await generateBrief();await repository().save(brief);return new Response(null,{status:204});};
export const config={schedule:"30 2 * * *"};
