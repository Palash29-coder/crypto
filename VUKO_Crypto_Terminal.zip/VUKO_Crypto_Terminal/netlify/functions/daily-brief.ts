import {authorized,json,safeError} from '../shared/http';import {generateBrief,repository} from '../shared/brief';export default async(req:Request)=>{try{const repo=repository();const saved=await repo.get('latest');if(saved){if(saved.id!==new Date().toISOString().slice(0,10))saved.warnings=[...saved.warnings,'Latest stored report is from an earlier UTC day.'];return json(saved);}authorized(req);return json(await generateBrief());}catch(e){return safeError(e)}};

export const config={rateLimit:{windowLimit:5,windowSize:60,aggregateBy:['ip','domain']}};
