import {fetchNews} from '../shared/news';import {authorized,json,safeError} from '../shared/http';export default async(req:Request)=>{try{authorized(req);return json({stories:await fetchNews(),retrievedAt:new Date().toISOString()});}catch(e){return safeError(e)}};
export const config={rateLimit:{windowLimit:10,windowSize:60,aggregateBy:['ip','domain']}};
