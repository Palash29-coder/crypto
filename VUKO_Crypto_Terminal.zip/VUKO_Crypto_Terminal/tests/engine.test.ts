import {describe,it,expect} from 'vitest';import {ema,rsi,atr,closed,positionSize,validateMarketAnalysis,analyze,type Candle} from '../src/engine/market';import {backtest,defaults} from '../src/engine/backtest';
const make=(n:number,step=144e5):Candle[]=>Array.from({length:n},(_,i)=>({time:Date.UTC(2020,0,1)+i*step,closeTime:Date.UTC(2020,0,1)+(i+1)*step-1,open:100+i,high:102+i,low:99+i,close:101+i,volume:100}));
describe('Financial invariants',()=>{
 it('matches the requested risk sizing example',()=>{const p=positionSize(10000,.5,80000,78000,1,'long',84000);expect(p.units).toBe(.025);expect(p.risk).toBe(50);expect(p.notional).toBe(2000);expect(p.rr).toBe(2);});
 it('does not multiply risk by selected leverage',()=>{const a=positionSize(10000,.5,80000,78000,10);expect(a.risk).toBe(50);expect(a.margin).toBe(200);expect(a.effectiveLeverage).toBe(.2);});
 it('rejects invalid stops and non-finite numbers',()=>{expect(()=>positionSize(10000,.5,100,110)).toThrow();expect(()=>positionSize(10000,.5,100,100)).toThrow();expect(()=>positionSize(NaN,.5,100,90)).toThrow();});
 it('suppresses claims conflicting with mathematics',()=>{const facts={price:83981,ema20:84194,ema50:83000,ema200:80000,rsi:50,atr:300,atrPct:.35,volumeRatio:1,support:82000,resistance:86000};const result=validateMarketAnalysis(facts,[{metric:'ema20',relation:'above'}]);expect(result.valid).toBe(false);expect(result.warnings[0]).toContain('BELOW');});
 it('rejects inverted target and stop ordering',()=>{const facts={price:100,ema20:95,ema50:90,ema200:80,rsi:55,atr:3,atrPct:3,volumeRatio:1,support:90,resistance:110};expect(validateMarketAnalysis(facts,[],{side:'BUY',entry:100,stop:105,targets:[90]}).valid).toBe(false);});
 it('excludes an unfinished candle',()=>{const bars=make(30);expect(closed(bars,bars.at(-1)!.closeTime-100).length).toBe(29);});
 it('uses an SMA seed and Wilder indicators',()=>{expect(ema([1,2,3,4],3)).toEqual([null,null,2,3]);expect(rsi(Array.from({length:30},(_,i)=>i+1))).toBe(100);expect(rsi(Array(30).fill(10))).toBe(50);expect(atr(make(30))).toBe(3);});
 it('fails closed with insufficient history',()=>expect(analyze(make(20),make(100,864e5)).bias).toBe('WAIT'));
});
describe('Backtest causality and costs',()=>{
 const daily=make(550,864e5);const start=daily[300].time;const bars=make(260).map((c,i)=>({...c,time:start+i*144e5,closeTime:start+(i+1)*144e5-1,open:500+i,high:502.5+i,low:499+i,close:502+i}));
 it('produces entries only after a completed trigger and charges both sides',()=>{const r=backtest(bars,daily,{...defaults,start,end:bars.at(-1)!.time});expect(r.trades.length).toBeGreaterThan(0);for(const t of r.trades){const idx=bars.findIndex(c=>c.time===t.entryTime);const sig=bars[idx-1];const prior=bars.slice(idx-21,idx-1);expect(sig.close).toBeGreaterThan(Math.max(...prior.map(c=>c.high)));expect(t.fees).toBeGreaterThan(0);expect(t.entryTime).toBeGreaterThan(sig.closeTime);}expect(r.curve.at(-1)!.equity).toBeCloseTo(defaults.equity+r.trades.reduce((s,t)=>s+t.pnl,0),5);});
 it('does not use future candles in earlier decisions',()=>{const cut=180;const a=backtest(bars.slice(0,cut),daily,{...defaults,start,end:bars[cut-1].time});const modified=bars.map((c,i)=>i>=cut?{...c,open:c.open*3,close:c.close*3,high:c.high*3,low:c.low*3}:c);const b=backtest(modified,daily,{...defaults,start,end:bars.at(-1)!.time});expect(a.curve.slice(0,-1)).toEqual(b.curve.slice(0,a.curve.length-1));});
 it('forces a gap stop fill at the opening price or worse',()=>{const shocked=bars.map((c,i)=>i===100?{...c,open:100,high:110,low:90,close:100}:c);const r=backtest(shocked,daily,{...defaults,start,end:shocked.at(-1)!.time});const gap=r.trades.find(t=>t.reason==='Gap through stop');expect(gap).toBeDefined();expect(gap!.exit).toBeLessThanOrEqual(100);});
 it('rejects malformed parameter sets',()=>expect(()=>backtest(bars,daily,{...defaults,start,end:bars.at(-1)!.time,breakout:2.3})).toThrow());
});

describe('Prediction observation rules',()=>{
 it('does not invent intrabar ordering',async()=>{const {evaluatePrediction}=await import('../src/engine/predictions');const bars=make(2).map(c=>({...c,high:120,low:80,close:100}));const p={at:'2019-12-31',horizon:'2020-01-02',bias:'BUY',target:110,invalidation:90};expect(evaluatePrediction(p,bars).outcome).toBe('ambiguous');});
 it('ignores the candle containing the original recording time',async()=>{const {evaluatePrediction}=await import('../src/engine/predictions');const bar=make(1)[0];const p={at:new Date(bar.time+1000).toISOString(),horizon:'2020-01-02',bias:'BUY',target:102,invalidation:80};expect(evaluatePrediction(p,[bar]).outcome).toBe('pending');});
});
