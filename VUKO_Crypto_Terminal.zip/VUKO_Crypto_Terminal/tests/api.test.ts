import {describe,it,expect,afterEach,vi} from 'vitest';import {authorized,issueSession} from '../netlify/shared/http';import {normalizeTradingCursor} from '../src/services/tradingCursor';
afterEach(()=>vi.unstubAllEnvs());
describe('Secure adapter boundaries',()=>{
 it('disables paid endpoints when no workspace access secret is configured',()=>{vi.stubEnv('APP_ACCESS_PASSWORD','');expect(()=>authorized(new Request('https://vuko.example/api'))).toThrow('disabled');});
 it('accepts a signed session but rejects token tampering and cross-origin writes',()=>{vi.stubEnv('APP_ACCESS_PASSWORD','unit-test-password');const token=issueSession();expect(()=>authorized(new Request('https://vuko.example/api',{headers:{cookie:`vuko_session=${token}`,origin:'https://vuko.example'}}))).not.toThrow();expect(()=>authorized(new Request('https://vuko.example/api',{headers:{cookie:`vuko_session=${token.slice(0,-1)}z`}}))).toThrow();expect(()=>authorized(new Request('https://vuko.example/api',{headers:{cookie:`vuko_session=${token}`,origin:'https://attacker.example'}}))).toThrow();});
 it('rejects unstructured vendor recommendations',()=>expect(()=>normalizeTradingCursor({recommendation:'BUY',confidence:150})).toThrow());
});
