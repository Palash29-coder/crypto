# VUKO release-candidate status

This file separates implemented behavior from unavailable or incomplete production scope.

| Capability | Status | Boundary |
| --- | --- | --- |
| All 16 requested primary route patterns | Implemented | Mobile CSS and accessible native controls included; browser QA pending. |
| React, TypeScript, Vite, Tailwind, Zustand, TanStack Query, Zod, date-fns, Lucide | Implemented | Native controls used; no shadcn dependency. |
| Real-time prices | Implemented adapter | Public browser WebSocket plus REST polling, reconnect and stale tick suppression; provider availability unverified in deployment. |
| Market summary | Implemented | USD snapshot / USDT streaming price distinction disclosed. Fear-and-greed widget uses Alternative.me when available. |
| Global regime | Implemented subset | BTC/ETH trend, RSI, breadth; not all requested funding, dominance, liquidity and catalyst inputs. |
| Trade-bias engine | Implemented | Deterministic strategy; confidence is not win probability. |
| Narrative integrity | Implemented core | Numeric comparisons, EMA/RSI checks and level ordering; no general proof of arbitrary free-form LLM prose. |
| TradingCursor | Configurable gateway | MCP is not a browser API. A documented operator-owned HTTP gateway is required; no endpoint was invented. Connector check returned an error. |
| Screenshot analysis | Implemented secure workflow | OpenAI credential + access password required. Images are not persisted by VUKO. |
| Market table | Implemented core | Prices/returns/cap/volume/sparklines/favorites. On-demand technicals for the first eight filtered rows, plus full per-asset detail pages. |
| Heatmap | Implemented | 1H/24H/7D. Four-hour mode shows unavailable; no fabricated data. Square-root weighted tile sizing rather than exact market-cap area. |
| Movers | Implemented gainers | Market sorting provides losers/volume ordering. Dedicated unusual-activity and cross-market volatility models are pending. |
| Asset indicators | Implemented | EMA20/50/200, Wilder RSI/ATR, MACD line, Bollinger bands, volume. MACD signal/histogram not yet plotted. |
| Funding / open interest | Implemented adapter | Binance USD-M; regional/rate-limit availability applies. Liquidation history unavailable. |
| Daily report | Implemented deterministic synthesis | Source-linked news and BTC/ETH levels; unavailable sections labelled. LLM daily synthesis, calibrated scenario probabilities and complete on-chain/macro aggregation pending. |
| Scheduling | Implemented | Build-time configurable UTC cron, scheduled production Function. |
| Report persistence | Implemented adapters | Dynamic, Netlify Blobs, Supabase and Neon; SQL setup and credentials required where applicable. |
| Blockscout wallets | Implemented | Ethereum, Base, Optimism; first-page holdings/transactions/transfers/NFTs and verified ABI/source. No full historical pagination UI. |
| ENS | Implemented configurable | Ethereum mainnet RPC required; resolves address before selected-chain lookup. |
| Wallet observations | Implemented on refresh | Native/token balance differences and new transaction detection. Continuous background monitoring and notifications pending. |
| Quant lab | Implemented presets + parameters | Arbitrary custom Boolean strategy construction and walk-forward testing pending. |
| Backtest | Implemented spot research model | No funding, borrow, market-impact or liquidation model. Short mode is theoretical. |
| Robustness | Implemented | 27 combinations of 15/20/25 breakout, 1.5/2/2.5 ATR and 150/200/250 EMA; no statistical significance claims. |
| Position sizing | Implemented | Spot long / linear long-short, exposure, margin, reward/risk; liquidation warning is approximate. |
| Risk score | Implemented heuristic subset | Editable risk inputs, fixed scoring thresholds. No automatic correlations, funding or event calendar ingestion; no exchange-enforced account limits. |
| Journal / watchlist | Implemented local persistence | Not authenticated cloud sync; export available. |
| Prediction tracker | Implemented local ledger | Manual and on-demand market evaluation; ambiguous same-bar hits retained. No audited AI forecast archive or unattended scoring. |
| GitHub CI | Included | No repository exposed by connected GitHub account; no push performed. |
| Netlify deployment | Ready for owner setup | No deployment credentials/target connection available. Not published. |
| Notion | No changes | Search found no VUKO page; no parent was supplied. README/status file can be imported later. |

Public Equity Investing is aimed at listed-equity research; no equity research artifact was needed for this crypto application build.
