import {api} from './market';
export type WalletData={address:string;chain:string;info:any;tokens:any;transactions:any;transfers:any;nfts:any;abi:any;warnings:string[]};
export const chains=[{id:'ethereum',name:'Ethereum',host:'https://eth.blockscout.com',symbol:'ETH'},{id:'base',name:'Base',host:'https://base.blockscout.com',symbol:'ETH'},{id:'optimism',name:'Optimism',host:'https://optimism.blockscout.com',symbol:'ETH'}];
export const getWallet=(address:string,chain:string)=>api<WalletData>(`onchain?address=${encodeURIComponent(address)}&chain=${chain}`);
