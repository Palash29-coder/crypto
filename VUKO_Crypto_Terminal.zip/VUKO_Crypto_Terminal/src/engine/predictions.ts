import {closed,type Candle} from './market';
export function evaluatePrediction(p:{at:string;horizon:string;bias:string;target:number;invalidation:number},candles:Candle[],now=Date.now()){
 const start=Date.parse(p.at),end=Date.parse(p.horizon)+864e5-1;
 const bars=closed(candles,now).filter(c=>c.time>=start&&c.closeTime<=end);
 if(!bars.length)return {outcome:'pending' as const,actual:null,reason:'No completed candles fully inside the observation window.'};
 for(const c of bars){const target=p.bias==='BUY'?c.high>=p.target:c.low<=p.target;const stop=p.bias==='BUY'?c.low<=p.invalidation:c.high>=p.invalidation;if(target&&stop)return {outcome:'ambiguous' as const,actual:c.close,reason:'Both levels touched in one candle; intrabar order cannot be established.'};if(stop)return {outcome:'invalidated' as const,actual:p.invalidation,reason:'Invalidation touched before target in completed candles.'};if(target)return {outcome:'target' as const,actual:p.target,reason:'Target touched before invalidation in completed candles.'};}
 return {outcome:now>end?'expired' as const:'pending' as const,actual:bars.at(-1)!.close,reason:now>end?'Horizon elapsed without a recorded level touch.':'Neither level has been touched.'};
}
