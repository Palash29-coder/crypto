CREATE TABLE IF NOT EXISTS public.vuko_briefs (
  id text PRIMARY KEY,
  payload jsonb NOT NULL
);
-- Supabase: enable RLS with no anonymous policies. The server uses the service-role key.
ALTER TABLE public.vuko_briefs ENABLE ROW LEVEL SECURITY;
