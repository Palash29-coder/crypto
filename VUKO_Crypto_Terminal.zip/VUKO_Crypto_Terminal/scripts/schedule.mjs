import {writeFileSync} from 'node:fs';
const cron=process.env.DAILY_BRIEF_CRON||'30 2 * * *';
if(!/^[\d*,/\-]+(?: [\d*,/\-]+){4}$/.test(cron))throw new Error('DAILY_BRIEF_CRON must be a five-field UTC cron expression');
writeFileSync('netlify.toml',`[build]\ncommand = "npm run build"\npublish = "dist"\nfunctions = "netlify/functions"\n\n[build.environment]\nNODE_VERSION = "22"\n\n[functions]\nnode_bundler = "esbuild"\n\n[[redirects]]\nfrom = "/*"\nto = "/index.html"\nstatus = 200\n\n[[headers]]\nfor = "/*"\n[headers.values]\nX-Content-Type-Options = "nosniff"\nReferrer-Policy = "strict-origin-when-cross-origin"\nX-Frame-Options = "DENY"\nPermissions-Policy = "camera=(), microphone=(), geolocation=()"\nContent-Security-Policy = "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self' wss://stream.binance.com:9443; font-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'"\n`);

writeFileSync('netlify/functions/generate-daily-brief.ts',`import {generateBrief,repository} from '../shared/brief';
export default async()=>{const brief=await generateBrief();await repository().save(brief);return new Response(null,{status:204});};
export const config={schedule:${JSON.stringify(cron)}};
`);
